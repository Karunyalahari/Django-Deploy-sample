# Django Deploy Sample

A minimal Django project scaffold you can deploy and submit.

## How to use
1. Clone this repo.
2. (Optional) Create a virtualenv and install:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
3. Run locally:
   ```bash
   python manage.py migrate
   python manage.py runserver
   ```
4. Deploy (example: Heroku)
   - Create app: `heroku create your-app-name`
   - Set secret and debug (recommended):
     ```
     heroku config:set DJANGO_SECRET_KEY="your-secret"
     heroku config:set DEBUG=False
     heroku config:set ALLOWED_HOSTS=your-app-name.herokuapp.com
     ```
   - Push: `git push heroku main`
   - Run migrations on Heroku: `heroku run python manage.py migrate`
5. After your app is live, open it in the browser and copy the URL. Paste that URL into `DEPLOYMENT_URL.txt`, commit and push to GitHub.

## Task 24 submission
- Open `DEPLOYMENT_URL.txt` and replace the placeholder with your live deployment URL.
- Commit and push to GitHub.
